﻿namespace Library.DTO.Book
{
    public class HomeBooksDto
    {
        public IEnumerable<BookItemDto> AllBooks { get; set; }
        public IEnumerable<BookItemDto> LatestBooks { get; set; }
    }
}

