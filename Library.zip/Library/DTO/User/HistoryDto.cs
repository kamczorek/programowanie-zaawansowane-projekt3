﻿using Library.DTO.Rental;
using Library.DTO.Reservation;

namespace Library.DTO.User
{
    public class HistoryDto
    {
        public List<ReservationItemDto> Reservations { get; set; }
        public List<RentalItemDto> Rentals { get; set; }
    }
}
