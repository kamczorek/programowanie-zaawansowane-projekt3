﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace Library.DTO.User
{
    public class UpdateUserDto
    {
        public Guid Id { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Imię")]
        public string Name { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Nazwisko")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Nieprawidłowy adres e-mail")]
        public string Email { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Miasto")]
        public string City { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Ulica")]
        public string Street { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Budynek")]
        public string Building { get; set; }

        [Display(Name = "Mieszkanie")]
        public string Apartment { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Rola")]
        public string Role { get; set; }
    }
}

