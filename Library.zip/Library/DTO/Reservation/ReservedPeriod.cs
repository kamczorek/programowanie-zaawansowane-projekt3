﻿namespace Library.DTO.Reservation
{
    public class ReservedPeriod
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}

