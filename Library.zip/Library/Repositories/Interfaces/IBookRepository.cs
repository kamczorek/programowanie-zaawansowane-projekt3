﻿using Library.Models;

namespace Library.Repositories.Interfaces
{
    public interface IBookRepository
    {
        Task CreateAsync(Book book);
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<Book> GetBookByIdAsync(Guid id);
        Task DeleteBookByIdAsync(Guid id);
        Task UpdateBookAsync(Book book);
        Task ImportBooks(IEnumerable<Book> books);
    }
}

