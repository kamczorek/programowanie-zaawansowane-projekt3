﻿using Library.Models;

namespace Library.Repositories.Interfaces
{
    public interface IReservationRepository
    {
        Task CreateAsync(Reservation reservation);
        Task<IEnumerable<Reservation>> GetAllReservationsAsync();
        Task DeleteReservationAsync(Guid id);
        Task<Reservation> GetReservationByIdAsync(Guid id);
        Task<IEnumerable<Reservation>> GetReservationsByBookIdAsync(Guid id);
    }
}

