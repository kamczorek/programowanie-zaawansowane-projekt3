﻿using System.ComponentModel.DataAnnotations;

namespace Library.Models
{
    public class Rental: BookingData
    {
        [Key] 
        public Guid Id { get; set; }
        public string BookInfo { get; set; }
        public RentalStatus Status { get; set; }
    }

    public enum RentalStatus
    {
        Cancelled,
        Finished,
        Rent,
        WaitingToReceive
    }
}

