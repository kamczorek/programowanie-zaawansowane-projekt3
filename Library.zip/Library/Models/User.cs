﻿using Microsoft.AspNetCore.Identity;

namespace Library.Models
{
	public class User : IdentityUser<Guid>
	{
		public string Name { get; set; }
		public string LastName { get; set; }
		public string City { get; set; }
		public string Street { get; set; }
		public string Building { get; set; }
		public string Apartment { get; set; }
		public virtual ICollection<Reservation> Reservations { get; set; }
		public virtual ICollection<Rental> Rentals { get; set; }
	}

	public enum Role
	{
		User,
		Employee,
		Admin
	}
}

