﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Library.Models
{
    public class Book
    {
        [Key]
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Summary { get; set; }
        public BookStatus Status { get; set; }
        public string Author { get; set; }
        public string Type { get; set; }
        public string CoverImage { get; set; }
        public virtual ICollection<Rental> Rentals { get;}
        public virtual ICollection<Reservation> Reservations { get;}
        public DateTime CreationDate { get; set; }
        public override string ToString()
        {
            return $"{Title}, {Author}, {Type}";
        }
    }

    public enum BookStatus
    {
        Rent,
        Available
    }
}

