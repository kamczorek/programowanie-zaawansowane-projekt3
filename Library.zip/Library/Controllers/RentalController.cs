﻿using Library.Models;
using Library.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [Authorize(Roles = $"{nameof(Role.Employee)}")]
    public class RentalController : Controller
    {
        private readonly IRentalService _rentalService;
        public RentalController(IRentalService rentalService) 
        {
            _rentalService = rentalService;
        }

        public async Task<IActionResult> ChangeStatus(Guid id, RentalStatus status)
        {
            await _rentalService.ChangeStatusAsync(id, status);
            return RedirectToAction("GetRentals", "Dashboard");
        }
    }
}


