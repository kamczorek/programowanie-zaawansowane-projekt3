﻿using Library.Models;
using Library.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [Authorize]
    public class BookController : Controller
    {
        private readonly IBookService _bookService;
        public BookController(IBookService bookService)
        {
            _bookService = bookService;
        }

        public async Task<IActionResult> ViewBook(Guid id)
        {
            var book = await _bookService.GetBookByIdAsync(id);
            return View(book);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> DeleteBook(Guid id)
        {
            await _bookService.DeleteBookByIdAsync(id);
            return RedirectToAction("Index", "Home");
        }
    }
}

