﻿using Library.DTO.Book;
using Library.Models;
using Library.Repositories.Interfaces;
using Library.Services.Interfaces;

namespace Library.Services
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;
        public BookService(IBookRepository bookRepository) 
        {
            _bookRepository = bookRepository;
        }
        public async Task CreateBookAsync(BookItemDto bookItem)
        {
            var book = new Book
            {
                Title = bookItem.Title,
                Summary = bookItem.Summary,
                Author = bookItem.Author,
                CoverImage = bookItem.CoverImage,
                Status = BookStatus.Available,
                Type = bookItem.Type,
                CreationDate = DateTime.Now
            };

            await _bookRepository.CreateAsync(book);
        }

        public async Task DeleteBookByIdAsync(Guid id)
        {
            await _bookRepository.DeleteBookByIdAsync(id);
        }

        public async Task<IEnumerable<BookItemDto>> GetAllBooksAsync()
        {
            return (await _bookRepository.GetAllBooksAsync()).Select(book => new BookItemDto
            {
                Title = book.Title,
                Summary = book.Summary,
                Author = book.Author,
                CoverImage = book.CoverImage,
                Status = book.Status,
                Type = book.Type,
                Id = book.Id
            });
        }

        public async Task<BookItemDto> GetBookByIdAsync(Guid id)
        {
            var book = await _bookRepository.GetBookByIdAsync(id);
            return new BookItemDto
            {
                Title = book.Title,
                Summary = book.Summary,
                Author = book.Author,
                CoverImage = book.CoverImage,
                Status = book.Status,
                Type = book.Type,
                Id = book.Id
            };
        }

        public async Task<IEnumerable<BookItemDto>> GetLatestBooksAsync()
        {
            var books = await _bookRepository.GetAllBooksAsync();
            var latestBooks = books.OrderByDescending(x => x.CreationDate).Take(5);
            return latestBooks.Select(x => new BookItemDto { Title = x.Title, Author = x.Author, CoverImage = x.CoverImage, Id = x.Id });
        }

        public async Task UpdateBookAsync(BookItemDto request)
        {
            var book = await _bookRepository.GetBookByIdAsync(request.Id);
            book.Title = request.Title;
            book.Summary = request.Summary;
            book.Author = request.Author;
            book.CoverImage = request.CoverImage;
            book.Type = request.Type;

            await _bookRepository.UpdateBookAsync(book);
        }

        public async Task ChangeBookStatusAsync(Guid id, BookStatus status)
        {
            var book = await _bookRepository.GetBookByIdAsync(id);
            book.Status = status;
            await _bookRepository.UpdateBookAsync(book);
        }

        public async Task ImportBooksAsync(IEnumerable<Book> bookItems)
        {
            await _bookRepository.ImportBooks(bookItems);
        }
    }
}
