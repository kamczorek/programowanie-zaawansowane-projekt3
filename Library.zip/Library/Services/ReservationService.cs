﻿using Library.DTO.Reservation;
using Library.Models;
using Library.Repositories.Interfaces;
using Library.Services.Interfaces;

namespace Library.Services
{
    public class ReservationService: IReservationService
    {
        private readonly IReservationRepository _reservationRepository;
        private readonly IRentalService _rentalService;
        public ReservationService(IReservationRepository reservationRepository, IRentalService rentalService) 
        { 
            _reservationRepository = reservationRepository;
            _rentalService = rentalService;
        }

        public async Task CreateAsync(CreateReservationDto request)
        {
            var reservation = new Reservation
            {
                BookId = request.Id,
                UserId = request.UserId,
                DateFrom = request.StartDate,
                DateTo = request.EndDate
            };
            
            await _reservationRepository.CreateAsync(reservation);
        }

        public async Task<IEnumerable<ReservationItemDto>> GetAllReservationsAsync()
        {
            return (await _reservationRepository.GetAllReservationsAsync()).Select(x => new ReservationItemDto
            {
                Id = x.Id,
                BookId = x.BookId,
                UserId = x.UserId,
                StartDate = x.DateFrom,
                EndDate = x.DateTo,
                Name = x.User.Name,
                LastName = x.User.LastName,
                Title = x.Book.Title,
                Author = x.Book.Author,
                Type = x.Book.Type,
                CoverImage = x.Book.CoverImage
            });
        }

        public async Task MoveReservationToRentalAsync(Guid reservationId, bool decision)
        {
            var reservation = await _reservationRepository.GetReservationByIdAsync(reservationId);
            await _rentalService.CreateRentalAsync(reservation, decision);
            await _reservationRepository.DeleteReservationAsync(reservationId);
        }

        public async Task<IEnumerable<ReservedPeriod>> GetReservedAndRentedDatesAsync(Guid bookId)
        {
            var reservedDates = new List<ReservedPeriod>();
            var reservations = await _reservationRepository.GetReservationsByBookIdAsync(bookId);
            var rentals = await _rentalService.GetRentalsByBookIdAsync(bookId);
            rentals = rentals.Where(x => x.Status != RentalStatus.Finished && x.Status != RentalStatus.Cancelled);
            foreach (var reservation in reservations)
            {
                reservedDates.Add(new ReservedPeriod { StartDate = reservation.DateFrom, EndDate = reservation.DateTo });
            }
            foreach (var rental in rentals)
            {
                reservedDates.Add(new ReservedPeriod { StartDate = rental.DateFrom, EndDate = rental.DateTo });
            }

            return reservedDates;
        }
    }
}

