﻿using Library.DTO.Book;
using Library.Models;

namespace Library.Services.Interfaces
{
    public interface IBookService
    {
        Task CreateBookAsync(BookItemDto bookItem);
        Task<IEnumerable<BookItemDto>> GetAllBooksAsync();
        Task<BookItemDto> GetBookByIdAsync(Guid id);
        Task DeleteBookByIdAsync(Guid id);
        Task UpdateBookAsync(BookItemDto request);
        Task ChangeBookStatusAsync(Guid id, BookStatus status);
        Task ImportBooksAsync(IEnumerable<Book> bookItems);
        Task<IEnumerable<BookItemDto>> GetLatestBooksAsync();
    }
}

