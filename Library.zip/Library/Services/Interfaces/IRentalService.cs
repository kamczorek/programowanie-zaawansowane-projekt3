﻿using Library.DTO.Rental;
using Library.Models;

namespace Library.Services.Interfaces
{
    public interface IRentalService
    {
        Task CreateRentalAsync(Reservation reservation, bool decision);
        Task<IEnumerable<RentalItemDto>> GetAllRentalsAsync();
        Task ChangeStatusAsync(Guid rentalId, RentalStatus status);
        Task<IEnumerable<Rental>> GetRentalsByBookIdAsync(Guid bookId);
    }
}

