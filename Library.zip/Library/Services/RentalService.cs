﻿using Library.DTO.Rental;
using Library.Models;
using Library.Repositories.Interfaces;
using Library.Services.Interfaces;

namespace Library.Services
{
    public class RentalService: IRentalService
    {
        private readonly IRentalRepository _rentalRepository;
        private readonly IBookService _bookService;
        public RentalService(IRentalRepository rentalRepository, IBookService bookService)
        {
            _rentalRepository = rentalRepository;
            _bookService = bookService;
        }

        public async Task ChangeStatusAsync(Guid rentalId, RentalStatus status)
        {
            var rental = await _rentalRepository.GetRentalByIdAsync(rentalId);
            rental.Status = status;
            await _rentalRepository.UpdateRentalAsync(rental);
            var bookStatus = MapRentalStatusToBookStatus(status);
            await _bookService.ChangeBookStatusAsync(rental.BookId.Value, bookStatus);
        }

        public async Task CreateRentalAsync(Reservation reservation, bool decision)
        {
            var rental = new Rental
            {
                DateFrom = reservation.DateFrom,
                DateTo = reservation.DateTo,
                UserId = reservation.UserId,
                BookId = reservation.BookId,
                Status = decision ? RentalStatus.WaitingToReceive : RentalStatus.Cancelled,
                BookInfo = reservation.Book.ToString()
            };

            await _rentalRepository.CreateRentalAsync(rental);
        }

        public async Task<IEnumerable<RentalItemDto>> GetAllRentalsAsync()
        {
            var rentals = await _rentalRepository.GetAllRentalsAsync();
            return rentals.Select(x => new RentalItemDto
            {
                Id = x.Id,
                BookId = x.BookId,
                UserId = x.UserId,
                Name = x.User.Name,
                LastName = x.User.LastName,
                BookInfo = x.BookInfo,
                CoverImage = x.Book.CoverImage,
                StartDate = x.DateFrom,
                EndDate = x.DateTo,
                Status = x.Status,
                BookStatus = x.Book.Status
            });
        }

        public async Task<IEnumerable<Rental>> GetRentalsByBookIdAsync(Guid bookId)
        {
            return await _rentalRepository.GetRentalsByBookIdAsync(bookId);
        }

        private BookStatus MapRentalStatusToBookStatus(RentalStatus status)
        {
            return status switch
            {
                RentalStatus.Rent => BookStatus.Rent,
                RentalStatus.Cancelled => BookStatus.Available,
                RentalStatus.Finished => BookStatus.Available
            };
        }
        
    }
}

